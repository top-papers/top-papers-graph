Task 3 dual local model blind review bundle

Contents:
- offline_review/task3_dual_local_model_review_offline_ab.html
- variant_alpha/* and variant_beta/* : anonymized hypothesis outputs
- expert_review/task3_dual_local_model_review_manifest.json

Important: owner-side identity key is intentionally excluded to preserve blind review.
